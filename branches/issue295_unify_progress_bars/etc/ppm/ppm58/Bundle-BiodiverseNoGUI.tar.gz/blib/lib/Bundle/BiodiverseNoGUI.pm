package Bundle::BiodiverseNoGUI;

use strict;
use warnings;

use vars qw($VERSION);
our $VERSION = '0.15';

#  add the use statements so PPM will (hopefully) pick them up properly
use Data::DumpXML;
use Math::Random::MT::Auto;
use Devel::Symdump;
use Text::CSV_XS;
use DBD::XBase;
use HTML::QuickTable;
use YAML::Syck;
use PadWalker;
use Clone;
use Regexp::Common;
use lib;
#use mylib;
use parent;
use URI::Escape::XS;
use Geo::Converter::dms2dd;
use Statistics::Descriptive;
use Text::Wrapper;
use Exporter::Easy;


1;

__END__

=head1 NAME

Bundle::BiodiverseNoGUI - Bundle to install Biodiverse dependencies for non-GUI use

=head1 SYNOPSIS

  #  on Windows:
  perl -MCPAN -e 'install Bundle::BiodiverseNoGUI'
  
  #  on most other platforms:
  sudo perl -MCPAN -e 'install Bundle::BiodiverseNoGUI'

=head1 CONTENTS

Data::DumpXML
Math::Random::MT::Auto
Devel::Symdump
Text::CSV_XS
DBD::XBase
HTML::QuickTable
YAML::Syck
PadWalker
Clone
Regexp::Common
lib
mylib
parent
Readonly
URI::Escape::XS
Geo::Converter::dms2dd
Statistics::Descriptive
Text::Wrapper
Exporter::Easy

=head1 DESCRIPTION

CPAN Bundle file for Biodiverse dependencies for non-GUI use across all platforms.
Basically, it does not need GTK.

=head1 AUTHOR

Shawn Laffan
