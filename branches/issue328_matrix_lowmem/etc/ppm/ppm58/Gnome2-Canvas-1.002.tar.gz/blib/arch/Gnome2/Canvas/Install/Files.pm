package Gnome2::Canvas::Install::Files;

$self = {
          'inc' => '-mms-bitfields -IC:/GTK-2.10.6/include/libgnomecanvas-2.0 -IC:/GTK-2.10.6/include/gtk-2.0 -IC:/GTK-2.10.6/include/pango-1.0 -I/home/ivan/cross/build/include/freetype2 -I/home/ivan/cross/build/include -IC:/GTK-2.10.6/include/libart-2.0 -IC:/GTK-2.10.6/lib/gtk-2.0/include -IC:/GTK-2.10.6/include/atk-1.0 -IC:/GTK-2.10.6/include/cairo -IC:/GTK-2.10.6/include/glib-2.0 -IC:/GTK-2.10.6/lib/glib-2.0/include  ',
          'typemaps' => [
                          'canvas.typemap',
                          'gnomecanvasperl.typemap'
                        ],
          'deps' => [
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => '-Wl,--rpath -Wl,/home/ivan/cross/build/lib -user32 -Wl,-luuid -LC:/GTK-2.10.6/lib -L/home/ivan/cross/build/lib -lgnomecanvas-2.0 -lgtk-win32-2.0 -lart_lgpl_2 -lgdk-win32-2.0 -limm32 -lshell32 -lole32 -latk-1.0 -lgdk_pixbuf-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lcairo -lpangoft2-1.0 -lfontconfig -lfreetype -lz -lpango-1.0 -lm -lgobject-2.0 -lgmodule-2.0 -lglib-2.0 -lintl -liconv  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gnome2/Canvas/Install/Files.pm") {
			$CORE = $_ . "/Gnome2/Canvas/Install/";
			last;
		}
	}

1;
