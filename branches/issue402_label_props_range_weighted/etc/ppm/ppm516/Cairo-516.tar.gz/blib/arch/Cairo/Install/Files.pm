package Cairo::Install::Files;

$self = {
          'inc' => '-I. -Ibuild -mms-bitfields -IC:/strawberry32/c/include/cairo -IC:/strawberry32/c/include/glib-2.0 -IC:/strawberry32/c/lib/glib-2.0/include -IC:/strawberry32/c/include/pixman-1 -IC:/strawberry32/c/include -IC:/strawberry32/c/include/freetype2 -IC:/strawberry32/c/include/libpng15   -mms-bitfields -IC:/strawberry32/c/include/cairo -IC:/strawberry32/c/include/freetype2 -IC:/strawberry32/c/include -IC:/strawberry32/c/include/glib-2.0 -IC:/strawberry32/c/lib/glib-2.0/include -IC:/strawberry32/c/include/pixman-1 -IC:/strawberry32/c/include/libpng15  ',
          'typemaps' => [
                          'cairo-perl-auto.typemap',
                          'cairo-perl.typemap'
                        ],
          'deps' => [],
          'libs' => '-LC:/strawberry32/c/lib -lcairo   -LC:/strawberry32/c/lib -lcairo -lfreetype  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Cairo/Install/Files.pm") {
			$CORE = $_ . "/Cairo/Install/";
			last;
		}
	}

1;
