package Cairo::Install::Files;

$self = {
          'inc' => '-I. -Ibuild -mms-bitfields -IC:/strawberry/c/include/cairo -IC:/strawberry/c/include/glib-2.0 -IC:/strawberry/c/lib/glib-2.0/include -IC:/strawberry/c/include/pixman-1 -IC:/strawberry/c/include -IC:/strawberry/c/include/freetype2 -IC:/strawberry/c/include/libpng15   -mms-bitfields -IC:/strawberry/c/include/cairo -IC:/strawberry/c/include/freetype2 -IC:/strawberry/c/include -IC:/strawberry/c/include/glib-2.0 -IC:/strawberry/c/lib/glib-2.0/include -IC:/strawberry/c/include/pixman-1 -IC:/strawberry/c/include/libpng15  ',
          'typemaps' => [
                          'cairo-perl-auto.typemap',
                          'cairo-perl.typemap'
                        ],
          'deps' => [],
          'libs' => '-LC:/strawberry/c/lib -lcairo   -LC:/strawberry/c/lib -lcairo -lfreetype  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Cairo/Install/Files.pm") {
			$CORE = $_ . "/Cairo/Install/";
			last;
		}
	}

1;
