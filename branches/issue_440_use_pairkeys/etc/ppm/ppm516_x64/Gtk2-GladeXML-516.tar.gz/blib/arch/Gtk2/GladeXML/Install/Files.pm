package GladeXML::Install::Files;

$self = {
          'inc' => '-mms-bitfields -IC:/strawberry/c/include/libglade-2.0 -IC:/strawberry/c/include/gtk-2.0 -IC:/strawberry/c/include/libxml2 -IC:/strawberry/c/lib/gtk-2.0/include -IC:/strawberry/c/include/atk-1.0 -IC:/strawberry/c/include/cairo -IC:/strawberry/c/include/gdk-pixbuf-2.0 -IC:/strawberry/c/include/pango-1.0 -IC:/strawberry/c/include/glib-2.0 -IC:/strawberry/c/lib/glib-2.0/include -IC:/strawberry/c/include/pixman-1 -IC:/strawberry/c/include -IC:/strawberry/c/include/freetype2 -IC:/strawberry/c/include/libpng15  ',
          'typemaps' => [
                          'gladexmlperl.typemap'
                        ],
          'deps' => [
                      'Pango',
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => '-LC:/strawberry/c/lib -lglade-2.0 -lgtk-win32-2.0 -lxml2 -lgdk-win32-2.0 -latk-1.0 -lgio-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lgdk_pixbuf-2.0 -lpango-1.0 -lcairo -lgobject-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/GladeXML/Install/Files.pm") {
			$CORE = $_ . "/GladeXML/Install/";
			last;
		}
	}

1;
