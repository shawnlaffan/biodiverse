package Bundle::Biodiverse;

use strict;
use warnings;

#use vars qw($VERSION);
our $VERSION = '0.15';

#  add the use statements so PPM will (hopefully) pick them up properly
use Geo::ShapeFile;
use Tree::R;
use ExtUtils::Depends;
use ExtUtils::PkgConfig;
use Gtk2::GladeXML;
use Browser::Open;

1;

__END__

=head1 NAME

Bundle::Biodiverse - Bundle to install Biodiverse dependencies.
You should install the BiodiverseNoGUI bundle first.

=head1 SYNOPSIS

  #  on Windows:
  perl -MCPAN -e 'install Bundle::BiodiverseNoGUI'
  perl -MCPAN -e 'install Bundle::Biodiverse'
  
  #  on most other platforms:
  sudo perl -MCPAN -e 'install Bundle::BiodiverseNoGUI'
  sudo perl -MCPAN -e 'install Bundle::Biodiverse'

=head1 CONTENTS

Geo::ShapeFile
Tree::R
Gtk2::GladeXML
ExtUtils::Depends
ExtUtils::PkgConfig
Browser::Open


=head1 DESCRIPTION

CPAN Bundle file for Biodiverse dependencies across all platforms.  

=head1 AUTHOR

Shawn Laffan
