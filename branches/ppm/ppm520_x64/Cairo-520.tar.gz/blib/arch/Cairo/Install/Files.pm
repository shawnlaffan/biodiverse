package Cairo::Install::Files;

$self = {
          'typemaps' => [
                          'cairo-perl-auto.typemap',
                          'cairo-perl.typemap'
                        ],
          'deps' => [],
          'libs' => '-Lc:/strawberry/c/lib -lcairo   -Lc:/strawberry/c/lib -lcairo -lfreetype  ',
          'inc' => '-I. -Ibuild -mms-bitfields -Ic:/strawberry/c/include/cairo -Ic:/strawberry/c/include/glib-2.0 -Ic:/strawberry/c/lib/glib-2.0/include -Ic:/strawberry/c/include/pixman-1 -Ic:/strawberry/c/include -Ic:/strawberry/c/include/freetype2 -Ic:/strawberry/c/include/libpng16   -mms-bitfields -Ic:/strawberry/c/include/cairo -Ic:/strawberry/c/include/freetype2 -Ic:/strawberry/c/include -Ic:/strawberry/c/include/glib-2.0 -Ic:/strawberry/c/lib/glib-2.0/include -Ic:/strawberry/c/include/pixman-1 -Ic:/strawberry/c/include/libpng16  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Cairo/Install/Files.pm") {
			$CORE = $_ . "/Cairo/Install/";
			last;
		}
	}

1;
