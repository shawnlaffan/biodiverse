package Gtk2::Install::Files;

$self = {
          'inc' => '-mms-bitfields -Ic:/strawberry/c/include/gtk-2.0 -Ic:/strawberry/c/lib/gtk-2.0/include -Ic:/strawberry/c/include/atk-1.0 -Ic:/strawberry/c/include/cairo -Ic:/strawberry/c/include/gdk-pixbuf-2.0 -Ic:/strawberry/c/include/pango-1.0 -Ic:/strawberry/c/include/glib-2.0 -Ic:/strawberry/c/lib/glib-2.0/include -Ic:/strawberry/c/include/pixman-1 -Ic:/strawberry/c/include -Ic:/strawberry/c/include/freetype2 -Ic:/strawberry/c/include/libpng16   -I./build ',
          'typemaps' => [
                          'gtk2perl.typemap',
                          'gdk.typemap',
                          'gtk.typemap'
                        ],
          'deps' => [
                      'Glib',
                      'Cairo',
                      'Pango'
                    ],
          'libs' => '-Lc:/strawberry/c/lib -lgtk-win32-2.0 -lgdk-win32-2.0 -latk-1.0 -lgio-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lgdk_pixbuf-2.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gtk2/Install/Files.pm") {
			$CORE = $_ . "/Gtk2/Install/";
			last;
		}
	}

1;
