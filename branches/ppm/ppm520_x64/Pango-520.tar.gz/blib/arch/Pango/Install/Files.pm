package Pango::Install::Files;

$self = {
          'typemaps' => [
                          'pango-perl.typemap',
                          'pango.typemap'
                        ],
          'deps' => [
                      'Cairo',
                      'Glib'
                    ],
          'libs' => '-Lc:/strawberry/c/lib -lpango-1.0 -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  -Lc:/strawberry/c/lib -lpangocairo-1.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  ',
          'inc' => '-mms-bitfields -Ic:/strawberry/c/include/pango-1.0 -Ic:/strawberry/c/include/glib-2.0 -Ic:/strawberry/c/lib/glib-2.0/include   -I./build -mms-bitfields -Ic:/strawberry/c/include/pango-1.0 -Ic:/strawberry/c/include/cairo -Ic:/strawberry/c/include/glib-2.0 -Ic:/strawberry/c/lib/glib-2.0/include -Ic:/strawberry/c/include/pixman-1 -Ic:/strawberry/c/include -Ic:/strawberry/c/include/freetype2 -Ic:/strawberry/c/include/libpng16  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Pango/Install/Files.pm") {
			$CORE = $_ . "/Pango/Install/";
			last;
		}
	}

1;
