package Gnome2::Canvas::Install::Files;

$self = {
          'inc' => '-mms-bitfields -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/libgnomecanvas-2.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/pango-1.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/gail-1.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/libart-2.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/gtk-2.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/glib-2.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/lib/glib-2.0/include -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/freetype2 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/atk-1.0 -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/lib/gtk-2.0/include -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/cairo -ID:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/include/libpng14  ',
          'typemaps' => [
                          'canvas.typemap',
                          'gnomecanvasperl.typemap'
                        ],
          'deps' => [
                      'Pango',
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => 'D:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/../perl/site/lib/auto/Cairo/Cairo.a -LD:/shawn/svn/biodiverse_trunk/etc/win32_gtk/ex/lib -lgnomecanvas-2 -lart_lgpl_2 -lgtk-win32-2.0 -lgdk-win32-2.0 -latk-1.0 -lgio-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lgdk_pixbuf-2.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gnome2/Canvas/Install/Files.pm") {
			$CORE = $_ . "/Gnome2/Canvas/Install/";
			last;
		}
	}

1;
