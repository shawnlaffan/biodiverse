package GladeXML::Install::Files;

$self = {
          'inc' => '-mms-bitfields -IC:/GTK-2.10.6/include/libglade-2.0 -IC:/GTK-2.10.6/include/gtk-2.0 -IC:/GTK-2.10.6/include/libxml2 -IC:/GTK-2.10.6/lib/gtk-2.0/include -IC:/GTK-2.10.6/include/atk-1.0 -IC:/GTK-2.10.6/include/cairo -IC:/GTK-2.10.6/include/pango-1.0 -IC:/GTK-2.10.6/include/glib-2.0 -IC:/GTK-2.10.6/lib/glib-2.0/include -I/home/ivan/cross/build/include/freetype2 -I/home/ivan/cross/build/include  ',
          'typemaps' => [
                          'gladexmlperl.typemap'
                        ],
          'deps' => [
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => '-user32 -Wl,-luuid -Wl,--rpath -Wl,/home/ivan/cross/build/lib -LC:/GTK-2.10.6/lib -L/home/ivan/cross/build/lib -lglade-2.0 -lgtk-win32-2.0 -lxml2 -lgdk-win32-2.0 -limm32 -lshell32 -lole32 -latk-1.0 -lgdk_pixbuf-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lcairo -lpangoft2-1.0 -lfontconfig -lfreetype -lz -lpango-1.0 -lm -lgobject-2.0 -lgmodule-2.0 -lglib-2.0 -lintl -liconv   C:/Perl/site/lib/auto/Glib/Glib.lib C:/Perl/site/lib/auto/Gtk2/Gtk2.lib C:/Perl/site/lib/auto/Cairo/Cairo.lib'
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/GladeXML/Install/Files.pm") {
			$CORE = $_ . "/GladeXML/Install/";
			last;
		}
	}

1;
