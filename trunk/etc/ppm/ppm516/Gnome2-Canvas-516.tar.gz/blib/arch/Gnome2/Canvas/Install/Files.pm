package Gnome2::Canvas::Install::Files;

$self = {
          'inc' => '-mms-bitfields -IC:/strawberry32/c/include/libgnomecanvas-2.0 -IC:/strawberry32/c/include/pango-1.0 -IC:/strawberry32/c/include/gail-1.0 -IC:/strawberry32/c/include/libart-2.0 -IC:/strawberry32/c/include/gtk-2.0 -IC:/strawberry32/c/include/glib-2.0 -IC:/strawberry32/c/lib/glib-2.0/include -IC:/strawberry32/c/include/freetype2 -IC:/strawberry32/c/include -IC:/strawberry32/c/include/atk-1.0 -IC:/strawberry32/c/lib/gtk-2.0/include -IC:/strawberry32/c/include/cairo -IC:/strawberry32/c/include/gdk-pixbuf-2.0 -IC:/strawberry32/c/include/pixman-1 -IC:/strawberry32/c/include/libpng15  ',
          'typemaps' => [
                          'canvas.typemap',
                          'gnomecanvasperl.typemap'
                        ],
          'deps' => [
                      'Pango',
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => '-LC:/strawberry32/c/lib -lgnomecanvas-2 -lart_lgpl_2 -lgtk-win32-2.0 -lgdk-win32-2.0 -latk-1.0 -lgio-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lgdk_pixbuf-2.0 -lpango-1.0 -lcairo -lgobject-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gnome2/Canvas/Install/Files.pm") {
			$CORE = $_ . "/Gnome2/Canvas/Install/";
			last;
		}
	}

1;
