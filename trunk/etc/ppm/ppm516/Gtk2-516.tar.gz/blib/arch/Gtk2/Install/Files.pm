package Gtk2::Install::Files;

$self = {
          'inc' => '-mms-bitfields -IC:/strawberry32/c/include/gtk-2.0 -IC:/strawberry32/c/lib/gtk-2.0/include -IC:/strawberry32/c/include/atk-1.0 -IC:/strawberry32/c/include/cairo -IC:/strawberry32/c/include/gdk-pixbuf-2.0 -IC:/strawberry32/c/include/pango-1.0 -IC:/strawberry32/c/include/glib-2.0 -IC:/strawberry32/c/lib/glib-2.0/include -IC:/strawberry32/c/include -IC:/strawberry32/c/include/freetype2 -IC:/strawberry32/c/include/libpng15   -I./build ',
          'typemaps' => [
                          'gtk2perl.typemap',
                          'gdk.typemap',
                          'gtk.typemap'
                        ],
          'deps' => [
                      'Pango',
                      'Glib',
                      'Cairo'
                    ],
          'libs' => '-LC:/strawberry32/c/lib -lgtk-win32-2.0 -lgdk-win32-2.0 -latk-1.0 -lgio-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lgdk_pixbuf-2.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gtk2/Install/Files.pm") {
			$CORE = $_ . "/Gtk2/Install/";
			last;
		}
	}

1;
