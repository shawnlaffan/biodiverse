package Pango::Install::Files;

$self = {
          'inc' => '-mms-bitfields -IC:/strawberry32/c/include/pango-1.0 -IC:/strawberry32/c/include/glib-2.0 -IC:/strawberry32/c/lib/glib-2.0/include   -I./build -mms-bitfields -IC:/strawberry32/c/include/pango-1.0 -IC:/strawberry32/c/include/cairo -IC:/strawberry32/c/include/glib-2.0 -IC:/strawberry32/c/lib/glib-2.0/include -IC:/strawberry32/c/include -IC:/strawberry32/c/include/freetype2 -IC:/strawberry32/c/include/libpng15  ',
          'typemaps' => [
                          'pango-perl.typemap',
                          'pango.typemap'
                        ],
          'deps' => [
                      'Glib',
                      'Cairo'
                    ],
          'libs' => '-LC:/strawberry32/c/lib -lpango-1.0 -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  -LC:/strawberry32/c/lib -lpangocairo-1.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Pango/Install/Files.pm") {
			$CORE = $_ . "/Pango/Install/";
			last;
		}
	}

1;
