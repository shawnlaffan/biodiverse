package GladeXML::Install::Files;

$self = {
          'inc' => '-mms-bitfields -Id:/shawn/gtk/ex/include/libglade-2.0 -Id:/shawn/gtk/ex/include/gtk-2.0 -Id:/shawn/gtk/ex/include -Id:/shawn/gtk/ex/lib/gtk-2.0/include -Id:/shawn/gtk/ex/include/atk-1.0 -Id:/shawn/gtk/ex/include/cairo -Id:/shawn/gtk/ex/include/pango-1.0 -Id:/shawn/gtk/ex/include/glib-2.0 -Id:/shawn/gtk/ex/lib/glib-2.0/include -Id:/shawn/gtk/ex/include/freetype2 -Id:/shawn/gtk/ex/include/libpng14  ',
          'typemaps' => [
                          'gladexmlperl.typemap'
                        ],
          'deps' => [
                      'Pango',
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => 'd:/shawn/gtk/ex/../perl/site/lib/auto/Cairo/Cairo.a -Ld:/shawn/gtk/ex/lib -lglade-2.0 -lgtk-win32-2.0 -lxml2 -lz -lgdk-win32-2.0 -latk-1.0 -lgio-2.0 -lgdk_pixbuf-2.0 -lpangowin32-1.0 -lgdi32 -lpangocairo-1.0 -lpango-1.0 -lcairo -lgobject-2.0 -lgmodule-2.0 -lgthread-2.0 -lglib-2.0 -lintl  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/GladeXML/Install/Files.pm") {
			$CORE = $_ . "/GladeXML/Install/";
			last;
		}
	}

1;
